<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller{

	public function __construct(){
		parent::__construct();

		$this->load->helper(array('form', 'url'));

        $this->load->library('form_validation');

        $this->load->library('session');

        $this->load->model('admin_model');
	}

	public function index(){ 
		if($this->session->userdata('logged_in')) {

			redirect("admin/dashboard", "location");
		}
		else{
			$this->load->view('a_login');
		}
		 
	}

	public function login(){ 

	 	$this->form_validation->set_rules('userEmail', 'Username', 'required');
        $this->form_validation->set_rules('userPwd', 'Password', 'required');

        if ($this->form_validation->run() == FALSE)
        {
			$this->index();
        }
        else
        { 
        	$data = array(
				'username' => $this->input->post('userEmail'),
				'password' => $this->input->post('userPwd')
				);
        	
        	$result = $this->admin_model->checkLogin($data);
        	if ($result != false) {
				$session_data = array(
				'username' => $result[0]->admin_id,
				'email' => $result[0]->user_name,
				);
				// Add user data in session
				$this->session->set_userdata('logged_in', $session_data);
				redirect("admin/dashboard", "location");//$this->dashboard();
			}else {
				$data = array(
				'error_message' => 'Invalid Username or Password'
				);
				$this->load->view('a_login', $data);
			}
        }
	}
	public function dashboard(){
		if($this->session->userdata('logged_in')) {

			$this->load->view('dashboard');
		}
		else{
			redirect("admin/index", "location");
		}
		
	}
	public function addCategory(){
		$this->load->view('addCategory');
	}
	public function insertCategory(){
		$this->form_validation->set_rules('category', 'Category Name', 'required');
		if ($this->form_validation->run() == FALSE)
        {
                $this->load->view('addCategory');
        }
        else
        {
        	$config['upload_path'] = 'assets/images/category/';
	        $config['allowed_types'] = 'gif|jpg|png';
	        $config['max_size'] = 2000;
	        $config['max_width'] = 1500;
	        $config['max_height'] = 1500;
	        $this->load->library('upload', $config);
	        if (!$this->upload->do_upload('category_image')) {
	            $error = array('error' => $this->upload->display_errors());
	            $this->load->view('addCategory', $error);
	        } else {
				$upload_data = $this->upload->data();
				$data = array(
					'category' => $this->input->post('category'),
					'image' => $upload_data['file_name'],
					'description' => $this->input->post('description')
					);
				$result = $this->admin_model->storeCategory($data);
				if($result != false){ 
					redirect("admin/listCategory", "location");
				}else {
					$error = array('error' => 'Oops..Something went wrong');
					$this->load->view('addCategory', $error);
				}
	        }
        }
	}
	public function listCategory(){
		$result['data']=$this->admin_model->allCategories();
		$this->load->view('listCategory',$result);
	}
	public function addBanner(){
		$result['data'] = false;
		$this->load->view('addBanner',$result);
	}
	public function insertBanner(){
		$this->form_validation->set_rules('caption', 'Caption', 'required');
		if ($this->form_validation->run() == FALSE)
        {
                $this->load->view('addBanner');
        }
        else
        {
        	$config['upload_path'] = 'assets/images/banner/';
	        $config['allowed_types'] = 'gif|jpg|png';
	        $config['max_size'] = 2000;
	        $config['max_width'] = 1500;
	        $config['max_height'] = 1500;
	        $this->load->library('upload', $config);
	        if (!$this->upload->do_upload('banner_image')) {
	            $error = array('error' => $this->upload->display_errors());
	            $this->load->view('addBanner', $error);
	        } else {
				$upload_data = $this->upload->data();
				$data = array(
					'caption' => $this->input->post('caption'),
					'image' => $upload_data['file_name']
					);
				$result = $this->admin_model->uploadBanner($data);
				if($result != false){ 
					redirect("admin/listBanner", "location");
				}else {
					$error = array('error' => 'Oops..Something went wrong');
					$this->load->view('addBanner', $error);
				}
	        }
        }
	}
	public function listBanner(){
		$result['data']=$this->admin_model->allBanners();
		$this->load->view('listBanner',$result);
	}
	public function editBanner($id){ 
		if(!empty($id))
		{ 
			$result['data'] = $this->admin_model->getBannerDetails($id);
			if ($this->input->server('REQUEST_METHOD') === 'POST')
			{
				$this->form_validation->set_rules('caption', 'Caption', 'required');
				if ($this->form_validation->run() == FALSE)
		        {
		                $this->load->view('addBanner',$result);
		        }
		        else
		        {
		        	
		        }
			}
			else{ 
				if ($result['data'] != false) {
					$this->load->view('addBanner',$result);
				}
				else{
					redirect("admin/listBanner", "location");
				}
			}
		}
		else{
			redirect("admin/listBanner", "location");
		}

	}
	public function logout(){
		$this->session->sess_destroy();
		redirect("admin/index", "location");
	}
}
?>
