<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller{

	public function __construct(){
		parent::__construct();

		$this->load->helper(array('form', 'url'));

        $this->load->library('form_validation');

        $this->load->library('session');

        $this->load->model('admin_model');
	}

	public function index(){ 
		if($this->session->userdata('logged_in')) {

			redirect("admin/dashboard", "location");
		}
		else{
			$this->load->view('a_login');
		}
		 
	}

	public function login(){ 

	 	$this->form_validation->set_rules('userEmail', 'Username', 'required');
        $this->form_validation->set_rules('userPwd', 'Password', 'required');

        if ($this->form_validation->run() == FALSE)
        {
			$this->index();
        }
        else
        { 
        	$data = array(
				'username' => $this->input->post('userEmail'),
				'password' => $this->input->post('userPwd')
				);
        	
        	$result = $this->admin_model->checkLogin($data);
        	if ($result != false) {
				$session_data = array(
				'username' => $result[0]->admin_id,
				'email' => $result[0]->user_name,
				);
				// Add user data in session
				$this->session->set_userdata('logged_in', $session_data);
				redirect("admin/dashboard", "location");//$this->dashboard();
			}else {
				$data = array(
				'error_message' => 'Invalid Username or Password'
				);
				$this->load->view('a_login', $data);
			}
        }
	}
	public function dashboard(){
		if($this->session->userdata('logged_in')) {

			$this->load->view('dashboard');
		}
		else{
			redirect("admin/index", "location");
		}
		
	}
	public function addCategory(){
		$this->load->view('addCategory');
	}
	public function insertCategory(){
		$this->form_validation->set_rules('category', 'Category Name', 'required');
		if ($this->form_validation->run() == FALSE)
        {
                $this->load->view('addCategory');
        }
        else
        {
        	$config['upload_path'] = 'assets/images/category/';
	        $config['allowed_types'] = 'gif|jpg|png';
	        $config['max_size'] = 2000;
	        $config['max_width'] = 1500;
	        $config['max_height'] = 1500;
	        $this->load->library('upload', $config);
	        if (!$this->upload->do_upload('category_image')) {
	            $error = array('error' => $this->upload->display_errors());
	            $this->load->view('addCategory', $error);
	        } else {
				$upload_data = $this->upload->data();
				$data = array(
					'category' => $this->input->post('category'),
					'image' => $upload_data['file_name'],
					'description' => $this->input->post('description')
					);
				$result = $this->admin_model->storeCategory($data);
				if($result != false){ 
					redirect("admin/listCategory", "location");
				}else {
					$error = array('error' => 'Oops..Something went wrong');
					$this->load->view('addCategory', $error);
				}
	        }
        }
	}
	public function listCategory(){
		$result['data']=$this->admin_model->allCategories();
		$this->load->view('listCategory',$result);
	}
	public function addBanner(){
		$result['data'] = false;
		$this->load->view('addBanner',$result);
	}
	public function insertBanner(){
		$this->form_validation->set_rules('caption', 'Caption', 'required');
		
		if ($this->form_validation->run() == FALSE)
        {
        	$result['data'] = false;
            $this->load->view('addBanner',$result);
        }
        else
        {
        	$config['upload_path'] = 'assets/images/banner/';
	        $config['allowed_types'] = 'gif|jpg|png';
	        $config['max_size'] = 2000;
	        $config['max_width'] = 1500;
	        $config['max_height'] = 1500;
	        $this->load->library('upload', $config);
	        if (!$this->upload->do_upload('banner_image')) {
	            $result['error'] = array('error' => $this->upload->display_errors());
	            $this->load->view('addBanner', $error);
	        } else {
				$upload_data = $this->upload->data();
				$data = array(
					'caption' => $this->input->post('caption'),
					'image' => $upload_data['file_name']
					);
				$result = $this->admin_model->uploadBanner($data);
				if($result != false){ 
					redirect("admin/listBanner", "location");
				}else {
					$result['error'] = array('error' => 'Oops..Something went wrong');
					$this->load->view('addBanner', $error);
				}
	        }
        }
	}
	public function listBanner(){
		$result['data']=$this->admin_model->allBanners();
		$this->load->view('listBanner',$result);
	}
	public function editBanner($id){ 
		if(!empty($id))
		{ 
			$result['data'] = $this->admin_model->getBannerDetails($id);
			if ($this->input->server('REQUEST_METHOD') === 'POST')
			{
				$this->form_validation->set_rules('caption', 'Caption', 'required');
				if ($this->form_validation->run() == FALSE)
		        {
	                $this->load->view('addBanner',$result);
		        }
		        else
		        {
		        	if (!empty($_FILES['banner_image']['name']))
					{
						$config['upload_path'] = 'assets/images/banner/';
				        $config['allowed_types'] = 'gif|jpg|png';
				        $config['max_size'] = 2000;
				        $config['max_width'] = 1500;
				        $config['max_height'] = 1500;
				        $this->load->library('upload', $config);
				        if (!$this->upload->do_upload('banner_image')) {
				            $result['error'] = array('error' => $this->upload->display_errors());
				            $this->load->view('addBanner', $result);
				        } else {
							$upload_data = $this->upload->data();
							$data = array(
								'caption' => $this->input->post('caption'),
								'image' => $upload_data['file_name'],
								'modified_date' => date('Y-m-d h:i')
								);
							$qryresult = $this->admin_model->updateBanner($id,$data);
							if($qryresult != false){ 
								redirect("admin/listBanner", "location");
							}else {
								$result['error'] = array('error' => 'Oops..Something went wrong');
								$this->load->view('addBanner', $result);
							}
				        } 
					}
					else{
						$data = array(
								'caption' => $this->input->post('caption'),
								'image' => '',
								'modified_date' => date('Y-m-d h:i')
								);
							$qryresult = $this->admin_model->updateBanner($id,$data);
							if($qryresult != false){ 
								redirect("admin/listBanner", "location");
							}else {
								$result['error'] = array('error' => 'Oops..Something went wrong');
								$this->load->view('addBanner', $result);
							}
					}
		        }
			}
			else{ 
				if ($result['data'] != false) {
					$this->load->view('addBanner',$result);
				}
				else{
					redirect("admin/listBanner", "location");
				}
			}
		}
		else{
			redirect("admin/listBanner", "location");
		}

	}
	public function deleteBanner($id){ 
		if(!empty($id))
		{ 
			$data = $this->admin_model->getBannerDetails($id);
			$banner_image = $data[0]->banner_image;
			$path = 'assets/images/banner/'.$banner_image;
			unlink($path);
			$qryresult = $this->admin_model->deleteBanner($id);
			if($qryresult != false){ 
				redirect("admin/listBanner", "location");
			}else {
				$result['error'] = array('error' => 'Oops..Something went wrong');
				$this->load->view('listBanner', $result);
			}
				
		}
		else{
			redirect("admin/listBanner", "location");
		}

	}
	public function profile(){
		$result['data'] = $this->admin_model->getProfileData();
		$this->load->view('updateProfile',$result);
	}
	public function updateProfile(){
		$data = $result = array();
		if (!empty($_FILES['profile_image']['name']))
		{
			$config['upload_path'] = 'assets/images/profile/';
	        $config['allowed_types'] = 'gif|jpg|png';
	        $config['max_size'] = 2000;
	        $config['max_width'] = 1500;
	        $config['max_height'] = 1500;
	        $this->load->library('upload', $config);
	        if (!$this->upload->do_upload('profile_image')) {
	            $result['error'] = array('error' => $this->upload->display_errors());
	            $this->profile();
	        } else {
				$upload_data = $this->upload->data();
				$data['image'] = $upload_data['file_name'];
			} 
		}
		if(!empty($this->input->post('username')))
		{
			$data['username'] = $this->input->post('username');
		}
		if(!empty($this->input->post('password')))
		{
			$data['password'] = $this->input->post('password');
		}
		if(!empty($data)){
			$qryresult = $this->admin_model->updateProfile($data);
			redirect("admin/profile", "location");
		}
		//echo '<pre>';print_r($data);exit;
	}
	public function addProduct(){
		$this->load->view('addProduct');
	}
	public function insertProduct(){
		$this->form_validation->set_rules('product', 'Product Name', 'required');
		$this->form_validation->set_rules('price', 'Price', 'required');
		if ($this->form_validation->run() == FALSE)
        {
                $this->load->view('addProduct');
        }
        else
        {
        	$config['upload_path'] = 'assets/images/products/';
	        $config['allowed_types'] = 'gif|jpg|png';
	        $config['max_size'] = 2000;
	        $config['max_width'] = 1500;
	        $config['max_height'] = 1500;
	        $this->load->library('upload', $config);
	        if (!$this->upload->do_upload('product_image')) {
	            $error = array('error' => $this->upload->display_errors());
	            $this->load->view('addProduct', $error);
	        } else {
				$upload_data = $this->upload->data();
				$data = array(
					'product' => $this->input->post('product'),
					'price' => $this->input->post('price'),
					'image' => $upload_data['file_name'],
					'description' => $this->input->post('description')
					);
				$result = $this->admin_model->storeProduct($data);
				if($result != false){ 
					redirect("admin/listProduct", "location");
				}else {
					$error = array('error' => 'Oops..Something went wrong');
					$this->load->view('addProduct', $error);
				}
	        }
        }
	}
	public function listProduct(){
		$result['data']=$this->admin_model->allProducts();
		$this->load->view('listProduct',$result);
	}
	public function logout(){
		$this->session->sess_destroy();
		redirect("admin/index", "location");
	}


}
?>
