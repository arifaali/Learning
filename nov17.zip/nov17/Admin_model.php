<?php
	Class Admin_model extends CI_Model { 
	
      Public function __construct() { 
         parent::__construct(); 
      } 

      public function checkLogin($data)
      { 
      	$password = md5($data['password']);
      	$condition = "user_name =" . "'" . $data['username'] . "' AND " . "user_password =" . "'" . $password . "'";
			$this->db->select('*');
			$this->db->from('tbl_admin_login');
			$this->db->where($condition);
			$this->db->limit(1);
			$query = $this->db->get();

			if ($query->num_rows() == 1) {
			return $query->result();
			} else {
			return false;
			}
		}
		public function getProfileData(){
			$id = $this->session->userdata('logged_in')['username'];
			$condition = "admin_id =" . $id;
			$this->db->select('admin_id,user_name,profile_image');
			$this->db->from('tbl_admin_login');
			$this->db->where($condition);
			$this->db->limit(1);
			$query = $this->db->get();

			if ($query->num_rows() == 1) {
			return $query->result();
			} else {
			return false;
			}
		}
		public function updateProfile($data){
			extract($data);
			$id = $this->session->userdata('logged_in')['username'];
			$this->db->where('admin_id', $id);
			$set = array();
		    if(!empty($username)){
				$set = array('user_name' => $username);
			}
			if(!empty($password)){
				$password = md5($password);
				$set = array('user_password' => $password);
			}
			if(!empty($image)){
				$set = array('profile_image' => $image);
			}
			if(!empty($set)){
				$this->db->update('tbl_admin_login', $set);
			}
			return true;
		}
		public function storeCategory($data){ 
			$insert_data['categ_name'] = $data['category'];
			$insert_data['categ_image'] = $data['image'];
			$insert_data['categ_description'] = $data['description'];
			$query = $this->db->insert('tbl_product_category', $insert_data);
			return ($this->db->affected_rows() != 1) ? false : true;
		}

		function allCategories()
		{
			$this->db->select('*');
			$this->db->from('tbl_product_category');
			$this->db->where('delete_status = 0');
			$query = $this->db->get();
			if ($query->num_rows() > 0) {
				return $query->result();
			} else {
				return false;
			}
			//return $query->result();
		}
		public function uploadBanner($data){ 
			$insert_data['banner_caption'] = $data['caption'];
			$insert_data['banner_image'] = $data['image'];
			$query = $this->db->insert('tbl_banner', $insert_data);
			return ($this->db->affected_rows() != 1) ? false : true;
		}
		function allBanners()
		{
			$this->db->select('*');
			$this->db->from('tbl_banner');
			$this->db->where('delete_status = 0');
			$query = $this->db->get();
			if ($query->num_rows() > 0) {
				return $query->result();
			} else {
				return false;
			}
		}
		public function getBannerDetails($id)
      	{ 
      		$id = base64_decode($id);
      		$condition = "banner_id =" . "'" . $id . "'";
			$this->db->select('*');
			$this->db->from('tbl_banner');
			$this->db->where($condition);
			$this->db->limit(1);
			$query = $this->db->get();

			if ($query->num_rows() == 1) {
			return $query->result();
			} else {
			return false;
			}
		}
		public function updateBanner($id,$data){
			extract($data);
			$id = base64_decode($id);
		    $this->db->where('banner_id', $id);
		    if($image != '')
		    {
		    	$this->db->update('tbl_banner', array('banner_caption' => $caption, 'banner_image' =>$image, 'modified_date' => $modified_date));
		    }
		    else{
		    	$this->db->update('tbl_banner', array('banner_caption' => $caption, 'modified_date' => $modified_date));
		    }
		    
		    return true;
		}
		public function deleteBanner($id){
			$id = base64_decode($id);
			$this->db->delete('tbl_banner', array('banner_id' => $id)); 
			return true;
		}

		public function storeProduct($data){ 
			$insert_data['product'] = $data['product'];
			$insert_data['price'] = $data['price'];
			$insert_data['product_description'] = $data['description'];
			$query = $this->db->insert('tbl_products', $insert_data);
			$insert_id = $this->db->insert_id();
			if($insert_id){
				$img_data['product_id'] = $insert_id;
				$img_data['product_img'] = $data['image'];
				$query = $this->db->insert('tbl_product_images', $img_data);
				return true;
			}
			//return ($this->db->affected_rows() != 1) ? false : true;
		}

		function allProducts()
		{
			$this->db->select('*');
			$this->db->from('tbl_products');
			$this->db->where('delete_status = 0');
			$query = $this->db->get();
			if ($query->num_rows() > 0) {
				return $query->result();
			} else {
				return false;
			}
			//return $query->result();
		}

	} 
?>
