<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Products</title>
    
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/css/vendor.bundle.base.css">
    
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
    
    <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/images/favicon.png" />
  </head>
  <body>
    <div class="container-scroller">
      <!-- topNav -->
      <?php $this->load->view('topNav');?>
      <!-- topNav -->
      <div class="container-fluid page-body-wrapper">
        <!-- sidenav-->
        <?php $this->load->view('sideNav');?>
        <!-- sidenav -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title"> Products </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Products</a></li>
                  <li class="breadcrumb-item active" aria-current="page">All Products</li>
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> No. </th>
						  <th> Product </th>
						  <th> Price </th>
                          <th> Image </th>
                          <th> Description </th>
                          <th> Action </th>
                        </tr>
                      </thead>
                      <tbody>
					  <?php
						$i=1;
						if($data != false){ 
						foreach($data as $row)
						{
              $id = $row->product_id;
              ?>
							<tr>
								<td> <?php echo $i;?></td>
								<td> <?php echo $row->product;?></td>
								<td> <?php echo $row->price;?></td>
								<td class="py-1">
									<img src="<?php echo base_url(); ?>assets/images/category/<?php echo $row->price;?>" alt="image" />
								</td>
								<td> <?php echo $row->product_description;?></td>
								<td> 
                    <a href="<?= base_url('admin/editProduct/' . $id . '') ?>"><i class="mdi mdi-lead-pencil" title="Edit"></i></a> &nbsp;&nbsp;
                    <a href="<?= base_url('admin/deleteProduct/' . $id . '') ?>"><i class="mdi mdi-delete" title="Delete" onClick="return doconfirm();"></i></a>
                </td>
							</tr>
						<?php $i++; } } else{ ?>
						<tr><td>No data found</td><td></td><td></td><td></td><td></td><td></td></tr><?php } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              
              
              
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:<?php echo base_url(); ?>partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2017 <a href="https://www.bootstrapdash.com/" target="_blank">BootstrapDash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="mdi mdi-heart text-danger"></i></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="<?php echo base_url(); ?>assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo base_url(); ?>assets/js/off-canvas.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/hoverable-collapse.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <!-- End custom js for this page -->
  </body>
</html>
<script>
function doconfirm()
{
    job=confirm("Are you sure to delete permanently?");
    if(job!=true)
    {
        return false;
    }
}
</script>