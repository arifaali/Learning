<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Add Banner</title>
    
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/css/vendor.bundle.base.css">
    
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
    
    <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/images/favicon.png" />
    <style type="text/css">
    	.py-1{
    		width: 36px;
			height: 44px;
			border-radius: 100%;
    	}
    </style>
  </head>
  <body>
    <div class="container-scroller">
      <!-- topNav -->
      <?php $this->load->view('topNav');?>
      <!-- topNav -->
      <div class="container-fluid page-body-wrapper">
        <!-- sidenav-->
        <?php $this->load->view('sideNav');?>
        <!-- sidenav -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title"> Add Banner </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Banner</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Upload New</li>
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <?php
                if (isset($error)){
                    echo '<div class="text-danger">'.$error['error'].'</div>';//->error;
                }
            if($data != false){ 
              $banner_id = base64_encode($data[0]->banner_id);
              $banner_caption = $data[0]->banner_caption;
              $banner_image = $data[0]->banner_image;
              $action = base_url('admin/editBanner/'.$banner_id);
            }
            else{
              $banner_id = '';
              $banner_caption = '';
              $banner_image = '';
              $action = base_url('admin/insertBanner');
            }

            ?>
                    <form class="forms-sample" id="categForm" method="post" action="<?= $action ?>" enctype="multipart/form-data">
                      <div class="form-group">
                        <label for="exampleInputName1">Caption</label>
                        <input type="text" class="form-control" id="caption" name="caption" placeholder="Caption" value="<?php echo $banner_caption;?>">
                        <div class="text-danger"><?php echo form_error('caption'); ?></div>
                      </div>
                      <div class="form-group">
                        <label>File upload</label>
                       <?php if($banner_image != '') { ?> <img src="<?php echo base_url(); ?>assets/images/banner/<?php echo $banner_image;?>" alt="image" class="py-1"/><?php }?>
                        <input type="file" name="banner_image" id="banner_image" class="file-upload-default">
                       	<div class="input-group col-xs-12">
                          <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
                          <span class="input-group-append">
                            <button class="file-upload-browse btn btn-gradient-primary" type="button">Upload</button>
                          </span>
                        </div>
                         <div class="text-danger"><?php echo form_error('banner_image'); ?></div>
                      </div>
                      <button type="submit" class="btn btn-gradient-primary mr-2">Submit</button>
                      <a href="<?= base_url('admin/listBanner') ?>"><button class="btn btn-light" type="button">Cancel</button></a>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:<?php echo base_url(); ?>partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2017 <a href="https://www.bootstrapdash.com/" target="_blank">BootstrapDash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="mdi mdi-heart text-danger"></i></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="<?php echo base_url(); ?>assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo base_url(); ?>assets/js/off-canvas.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/hoverable-collapse.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="<?php echo base_url(); ?>assets/js/file-upload.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>
